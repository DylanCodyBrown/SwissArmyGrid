"""Python sessions that offer tables to the grid: the data behind the Open list.

A session is one running Python (a notebook kernel, a script, a REPL) whose client has the watcher
on (client/watch.py). It reports the names and sizes of the tables among its variables, never their
rows. The page lists them; a click queues a request, the session's listener picks it up and pushes
that one table. Rows therefore leave a Python process only when someone chooses to open a table.

In C# terms this is a presence registry, like the connected-users list of a SignalR hub: sessions
announce themselves, vanish when they stop announcing, and can be sent one message (a load request)
that they collect with a long poll.

A session also remembers which datasets it loaded. Those are the ones it keeps current ("follows")
when the variable is assigned again, for as long as the dataset stays open on the server.
"""

from __future__ import annotations

import asyncio
import re
from collections.abc import Callable
from dataclasses import dataclass, field
from time import monotonic
from typing import Any

from swissarmygrid.engine.datasets import NAME_PATTERN
from swissarmygrid.engine.relationships import Model, parse_model

MAX_TABLES: int = 500
MAX_LABEL_CHARS: int = 120
MAX_OFFERED_MODELS: int = 50
MAX_MODEL_CHARS: int = 200_000  # one model's JSON; the real ones are a few thousand
MAX_OFFER_ERROR_CHARS: int = 300
_PROCESS_ID = re.compile(r"[A-Za-z0-9_-]{1,64}")
_KIND = re.compile(r"[a-z_]{1,24}")


@dataclass
class Offer:
    """The relationship models a notebook is associated with, as its own Python found them in FI-Atlas.

    The session looks them up (it is the one with fi-clients and the user's sign-in) and hands them over
    once. `models` are already validated and parsed; `error` says why there are none or why some were
    skipped ("fi-clients is not installed in this Python"). `handled` turns true when the user applies
    some or skips them, so the page asks once per notebook session."""

    notebook: str
    models: dict[str, Model]
    error: str | None
    handled: bool = False


@dataclass
class _Session:
    id: str
    label: str
    pid: int
    tables: list[dict[str, Any]]
    last_seen: float
    loaded: set[str] = field(default_factory=set)
    requests: list[dict[str, str]] = field(default_factory=list)
    waiters: list[asyncio.Event] = field(default_factory=list)
    offer: Offer | None = None


def valid_process_id(value: str) -> bool:
    return bool(_PROCESS_ID.fullmatch(value))


def _count(value: Any, what: str) -> int | None:
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ValueError(f"A table's {what} must be a whole number or null.")
    return value


def _clean_tables(tables: Any) -> list[dict[str, Any]]:
    if not isinstance(tables, list):
        raise ValueError("tables must be a list.")
    if len(tables) > MAX_TABLES:
        raise ValueError(f"A session may list at most {MAX_TABLES} tables; this one sent too many.")
    cleaned: list[dict[str, Any]] = []
    seen: set[str] = set()
    for entry in tables:
        if not isinstance(entry, dict):
            raise ValueError("Each table is an object with a name, kind, rows and columns.")
        name, kind = entry.get("name"), entry.get("kind")
        if not isinstance(name, str) or not NAME_PATTERN.fullmatch(name):
            raise ValueError(f"A table name must be 1 to 64 letters, digits, '_' or '-': {name!r} is not.")
        if not isinstance(kind, str) or not _KIND.fullmatch(kind):
            raise ValueError(f"The kind of table {name!r} is missing or not a plain word.")
        if name in seen:
            continue
        seen.add(name)
        cleaned.append(
            {
                "name": name,
                "kind": kind,
                "rows": _count(entry.get("rows"), "rows"),
                "columns": _count(entry.get("columns"), "columns"),
            }
        )
    return cleaned


def _offer_json(offer: Offer | None) -> dict[str, Any] | None:
    """What the page shows of an offer: names and sizes, never the models' bodies."""
    if offer is None:
        return None
    return {
        "notebook": offer.notebook,
        "error": offer.error,
        "handled": offer.handled,
        "models": [
            {
                "name": m.name,
                "description": m.description,
                "tables": sorted(m.tables()),
                "relationships": len(m.relationships),
            }
            for m in offer.models.values()
        ],
    }


class ProcessRegistry:
    """The live sessions. Used from the event loop only, so it needs no lock."""

    def __init__(self, ttl_seconds: float = 30.0, clock: Callable[[], float] = monotonic) -> None:
        self._ttl = ttl_seconds
        self._clock = clock
        self._sessions: dict[str, _Session] = {}

    # ===== presence =====

    def sync(self, process_id: str, label: Any, pid: Any, tables: Any) -> bool:
        """Record a session's report. Returns True when what the page shows changed: a new session, a
        new label, or a different table list. A heartbeat that repeats the last report returns False."""
        if not valid_process_id(process_id):
            raise ValueError("The process id must be 1 to 64 letters, digits, '_' or '-'.")
        if not isinstance(label, str) or not label.strip():
            raise ValueError("A session needs a label (its notebook or script).")
        if isinstance(pid, bool) or not isinstance(pid, int):
            raise ValueError("pid must be a whole number.")
        cleaned = _clean_tables(tables)
        label = label.strip()[:MAX_LABEL_CHARS]
        self.prune()
        now = self._clock()
        session = self._sessions.get(process_id)
        if session is None:
            self._sessions[process_id] = _Session(process_id, label, pid, cleaned, now)
            return True
        session.last_seen = now
        changed = (session.label, session.pid, session.tables) != (label, pid, cleaned)
        session.label, session.pid, session.tables = label, pid, cleaned
        return changed

    def touch(self, process_id: str) -> bool:
        """A long poll is also proof of life. False when the session is unknown or has expired."""
        self.prune()
        session = self._sessions.get(process_id)
        if session is None:
            return False
        session.last_seen = self._clock()
        return True

    def prune(self) -> bool:
        """Drop sessions that stopped reporting. True when any went."""
        cutoff = self._clock() - self._ttl
        gone = [pid for pid, s in self._sessions.items() if s.last_seen < cutoff]
        for pid in gone:
            for event in self._sessions.pop(pid).waiters:
                event.set()  # wake its listener; the next poll finds no session
        return bool(gone)

    def snapshot(self, is_open: Callable[[str], bool]) -> list[dict[str, Any]]:
        """Every live session with its tables, each marked open when this session loaded it and the
        server still holds it."""
        self.prune()
        sessions = sorted(self._sessions.values(), key=lambda s: (s.label.lower(), s.id))
        return [
            {
                "id": s.id,
                "label": s.label,
                "pid": s.pid,
                "tables": [{**t, "open": t["name"] in s.loaded and is_open(t["name"])} for t in s.tables],
                "models": _offer_json(s.offer),
            }
            for s in sessions
        ]

    # ===== offered models =====

    def wants_models(self, process_id: str) -> bool:
        """True while a known session has not yet said which models its notebook is associated with.
        The session's sync reply carries this, so a restarted server asks again and the answer is
        re-sent without the session having to remember anything."""
        session = self._sessions.get(process_id)
        return session is not None and session.offer is None

    def set_offer(self, process_id: str, notebook: Any, models: Any, error: Any) -> Offer | None:
        """Store a session's associated models. None when the session is unknown. A model that fails
        SwissArmyGrid's own validation is dropped and mentioned in `error`, never stored half-checked."""
        self.prune()
        session = self._sessions.get(process_id)
        if session is None:
            return None
        if not isinstance(notebook, str) or not notebook.strip():
            raise ValueError("An offer names its notebook.")
        if not isinstance(models, list) or len(models) > MAX_OFFERED_MODELS:
            raise ValueError(f"models is a list of at most {MAX_OFFERED_MODELS} models.")
        if error is not None and not isinstance(error, str):
            raise ValueError("error is text or null.")
        kept: dict[str, Model] = {}
        skipped: list[str] = []
        for raw in models:
            try:
                if len(str(raw)) > MAX_MODEL_CHARS:
                    raise ValueError("it is too large")
                model = parse_model(raw)
                kept[model.name] = model
            except ValueError as reason:
                name = raw.get("name") if isinstance(raw, dict) else None
                skipped.append(f"{name or 'a model'}: {reason}")
        notes = [error] if error else []
        if skipped:
            notes.append(f"{len(skipped)} model(s) skipped: " + "; ".join(skipped))
        text = " ".join(notes)[:MAX_OFFER_ERROR_CHARS] or None
        session.offer = Offer(notebook.strip()[:400], kept, text)
        return session.offer

    def offer(self, process_id: str) -> Offer | None:
        session = self._sessions.get(process_id)
        return session.offer if session else None

    def mark_handled(self, process_id: str) -> bool:
        session = self._sessions.get(process_id)
        if session is None or session.offer is None:
            return False
        session.offer.handled = True
        return True

    # ===== load requests =====

    def request_load(self, process_id: str, name: str) -> bool:
        """Queue a load of one of the session's tables. False when the session or table is unknown."""
        self.prune()
        session = self._sessions.get(process_id)
        if session is None or not any(t["name"] == name for t in session.tables):
            return False
        request = {"action": "load", "name": name}
        if request not in session.requests:
            session.requests.append(request)
        for event in session.waiters:
            event.set()
        return True

    async def wait_requests(self, process_id: str, wait: float) -> list[dict[str, str]]:
        """The session's pending requests, waiting up to `wait` seconds for one to arrive."""
        if not self.touch(process_id):
            return []
        session = self._sessions[process_id]
        if not session.requests and wait > 0:
            event = asyncio.Event()  # a fresh one per wait, so it never belongs to a finished loop
            session.waiters.append(event)
            try:
                await asyncio.wait_for(event.wait(), wait)
            except TimeoutError:
                pass
            finally:
                if event in session.waiters:
                    session.waiters.remove(event)
        taken, session.requests = session.requests, []
        return taken

    # ===== what a session keeps current =====

    def note_loaded(self, process_id: str, name: str) -> bool:
        """The session pushed `name` as a dataset. It now owns the name: another session that had
        loaded the same name stops following it. True when this changed which tables are open."""
        session = self._sessions.get(process_id)
        if session is None:
            return False
        changed = name not in session.loaded
        session.loaded.add(name)
        for other in self._sessions.values():
            if other is not session and name in other.loaded:
                other.loaded.discard(name)
                changed = True
        return changed

    def owns(self, process_id: str, name: str) -> bool:
        """True when this session loaded `name` and no other session has taken the name since."""
        session = self._sessions.get(process_id)
        return session is not None and name in session.loaded

    def following(self, process_id: str, exists: Callable[[str], bool]) -> list[str]:
        """The datasets this session loaded that the server still holds."""
        session = self._sessions.get(process_id)
        return sorted(n for n in session.loaded if exists(n)) if session else []

    def knows(self, process_id: str) -> bool:
        self.prune()
        return process_id in self._sessions
