"""Deploy SwissArmyGrid as its own Claude Code plugin in the fi-plugins marketplace.

The marketplace is the fi-claude-marketplace repo (`.claude-plugin/marketplace.json`); the plugin goes in
`Claude Plugins/swissarmygrid/`, beside video2md and asana-fi. This script owns that folder and that one
marketplace entry, and touches nothing else in the repo:

  1. builds the page for release (no source maps) and checks the bundle exists;
  2. builds the wheel with the page inside it (uv build);
  2b. packages the VS Code extension around that wheel (the extension carries the server, so it can install and
     update it; both share one version number);
  3. copies the plugin template from plugin/ here (the swissarmygrid-use skill: SKILL.md, the guide) and
     the wheel into wheels/ (removing older wheels), and the newest
     VSCode-Extensions/swissarmygrid-*.vsix into vscode/;
  4. writes the plugin manifest: the MCP server runs `uvx --from <wheel>[server] swissarmygrid-mcp`;
  5. adds or updates the "swissarmygrid" entry in the marketplace;
  6. shows what changed.

It never commits or pushes unless asked (--commit, --push), and then it stages only the paths it wrote.
Teammates get it with /plugin (fi-plugins, swissarmygrid), then run /finance-toolbox:swissarmygrid-setup (that
skill lives in the finance-toolbox plugin, not here), which installs the grid server once and the push client
into their VS Code project environments.

    .venv\\Scripts\\python deploy_plugin.py --dry-run
    .venv\\Scripts\\python deploy_plugin.py
    .venv\\Scripts\\python deploy_plugin.py --commit --asana 1215939987640104
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
# This project lives in the same repo as the marketplace: <repo>/Python-Imports/swissarmygrid.
DEFAULT_REPO = HERE.parents[1]
NAME = "swissarmygrid"
DESCRIPTION = (
    "SwissArmyGrid: show any DataFrame in a live local grid from VS Code (import swissarmygrid as sag; "
    "sag.push(df)), with Excel-style selection, Power Query-style steps, SQL, profiling, charts, a Key "
    "Finder for join columns, side-by-side compare of two tables, and verified Python export. Grids open "
    "as tabs; the Agent tab holds the Analysis Sandbox. Runs on 127.0.0.1 only; data stays in memory on your machine. The MCP server lets "
    "Claude read and shape grids under a privacy level you set in Settings, and a prompt hook tells "
    "it which table is in front. Set it up with /finance-toolbox:swissarmygrid-setup (needs uv and Python 3.12+)."
)
AUTHOR = {"name": "Dylan Brown", "email": "Dylan.Brown@asurion.com"}


def run(command: list[str], cwd: Path, dry: bool) -> str:
    print(f"$ {' '.join(command)}   (in {cwd})")
    if dry:
        return ""
    exe = shutil.which(command[0]) or command[0]
    result = subprocess.run([exe, *command[1:]], cwd=cwd, capture_output=True, text=True, check=False)
    if result.returncode != 0:
        sys.exit(f"Failed: {' '.join(command)}\n{result.stdout}\n{result.stderr}")
    return result.stdout


def version() -> str:
    for line in (HERE / "pyproject.toml").read_text(encoding="utf-8").splitlines():
        if line.startswith("version = "):
            return line.split('"')[1]
    sys.exit("No version in pyproject.toml")


def write_json(path: Path, data: object, dry: bool) -> bool:
    text = json.dumps(data, indent=2, ensure_ascii=False) + "\n"
    old = path.read_text(encoding="utf-8") if path.exists() else None
    if old == text:
        return False
    if not dry:
        path.parent.mkdir(parents=True, exist_ok=True)
        # newline="\n": the repo stores LF, and text mode on Windows would write CRLF.
        path.write_text(text, encoding="utf-8", newline="\n")
    return True


def main() -> None:
    parser = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter
    )
    parser.add_argument("--repo", type=Path, default=DEFAULT_REPO, help="the fi-claude-marketplace repo")
    parser.add_argument("--dry-run", action="store_true", help="print the steps, change nothing")
    parser.add_argument("--skip-web", action="store_true", help="reuse the existing web/static/build")
    parser.add_argument("--commit", action="store_true", help="commit the changed paths in the plugin repo")
    parser.add_argument("--push", action="store_true", help="push after committing (implies --commit)")
    parser.add_argument("--asana", default=None, help="Asana task id for the commit message")
    args = parser.parse_args()
    dry: bool = args.dry_run
    repo: Path = args.repo
    marketplace = repo / ".claude-plugin" / "marketplace.json"
    if not marketplace.is_file():
        sys.exit(f"No marketplace at {marketplace}")
    plugin = repo / "Claude Plugins" / NAME
    ver = version()

    # 1. the page, release build
    if not args.skip_web:
        build = HERE / "web" / "static" / "build"
        if build.exists() and not dry:
            shutil.rmtree(build)
        run(["npm", "run", "build:release"], HERE / "web", dry)
    if not dry and not (HERE / "web" / "static" / "build" / "main.js").is_file():
        sys.exit("The page bundle is missing; run npm install in web/ first.")

    # 2. the wheel, with the page inside it
    dist = HERE / "dist"
    if dist.exists() and not dry:
        shutil.rmtree(dist)
    run(["uv", "build", "--wheel", "--out-dir", str(dist)], HERE, dry)
    wheel_name = f"{NAME}-{ver}-py3-none-any.whl"
    wheel = dist / wheel_name
    if not dry and not wheel.is_file():
        sys.exit(f"Expected {wheel}")

    # 2b. the VS Code extension, packaged around this wheel: it carries the server, so it can install and update
    # it. Extension and server share a version (bundle-server.mjs refuses a mismatch). The .vsix lands in
    # VSCode-Extensions/, replacing the older one.
    os.environ["SWISSARMYGRID_WHEEL_DIR"] = str(dist)
    run(["npm", "run", "package"], repo / "VSCode-Extensions" / NAME, dry)

    # 3. the skill(s) from the template, and the wheel
    template = HERE / "plugin"
    for source in sorted(template.rglob("*")):
        if source.is_file():
            target = plugin / source.relative_to(template)
            print(f"copy {source.relative_to(HERE)} -> {target.relative_to(repo)}")
            if not dry:
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source, target)
    wheels = plugin / "wheels"
    print(f"copy {wheel_name} -> {wheels.relative_to(repo)}")
    if not dry:
        wheels.mkdir(parents=True, exist_ok=True)
        for old in wheels.glob(f"{NAME}-*.whl"):
            old.unlink()
        shutil.copy2(wheel, wheels / wheel_name)

    # 3b. the VS Code extension, built on its own in VSCode-Extensions/ (its package script). The finance-toolbox
    # swissarmygrid-setup skill installs it with `code --install-extension`, so the newest one ships beside the wheel.
    built = sorted(
        (repo / "VSCode-Extensions").glob(f"{NAME}-*.vsix"),
        key=lambda p: [int(n) for n in p.stem.removeprefix(f"{NAME}-").split(".")],
    )
    if not built:
        sys.exit(f"No {NAME}-*.vsix in {repo / 'VSCode-Extensions'}; package the extension first.")
    vsix = built[-1]
    vscode_dir = plugin / "vscode"
    print(f"copy {vsix.name} -> {vscode_dir.relative_to(repo)}")
    if not dry:
        vscode_dir.mkdir(parents=True, exist_ok=True)
        for old in vscode_dir.glob(f"{NAME}-*.vsix"):
            old.unlink()
        shutil.copy2(vsix, vscode_dir / vsix.name)

    # 4. the plugin manifest (this plugin is ours, so it is written whole)
    manifest = {
        "name": NAME,
        "version": ver,
        "description": DESCRIPTION,
        "author": AUTHOR,
        "mcpServers": {
            NAME: {
                "type": "stdio",
                "command": "uvx",
                "args": [
                    "--from",
                    f"${{CLAUDE_PLUGIN_ROOT}}/wheels/{wheel_name}[server]",
                    "swissarmygrid-mcp",
                ],
            }
        },
    }
    changed = write_json(plugin / ".claude-plugin" / "plugin.json", manifest, dry)
    print(f"plugin.json: {'written' if changed else 'already current'} (version {ver})")

    # 4b. the prompt hook: each prompt gets a short summary of the table in front (no values), the
    # way an IDE hands Claude the open file. The bare wheel (no [server] extra) starts fast, and
    # the path is quoted because the plugin folder ("Claude Plugins") has a space in it.
    hooks = {
        "hooks": {
            "UserPromptSubmit": [
                {
                    "hooks": [
                        {
                            "type": "command",
                            "command": f'uvx --from "${{CLAUDE_PLUGIN_ROOT}}/wheels/{wheel_name}" swissarmygrid-context',
                            "timeout": 10,
                        }
                    ]
                }
            ]
        }
    }
    changed = write_json(plugin / "hooks" / "hooks.json", hooks, dry)
    print(f"hooks.json: {'written' if changed else 'already current'}")

    # 5. the marketplace entry, leaving every other plugin as it was
    market = json.loads(marketplace.read_text(encoding="utf-8"))
    entry = {"name": NAME, "source": f"./Claude Plugins/{NAME}", "description": DESCRIPTION}
    plugins = market.setdefault("plugins", [])
    at = next((i for i, p in enumerate(plugins) if p.get("name") == NAME), None)
    if at is None:
        plugins.append(entry)
    else:
        plugins[at] = entry
    changed = write_json(marketplace, market, dry)
    print(f"marketplace.json: {'updated' if changed else 'already current'}")

    # 6. show, and optionally commit
    paths = [str(plugin.relative_to(repo)), str(marketplace.relative_to(repo))]
    print(run(["git", "status", "--short", "--", *paths], repo, False) or "(no changes)")
    if args.commit or args.push:
        run(["git", "add", "--", *paths], repo, dry)
        message = f"swissarmygrid plugin {ver}: grid server MCP and the swissarmygrid-use skill"
        if args.asana:
            message += f"\n\nAsana: {args.asana}"
        run(["git", "commit", "-m", message, "--", *paths], repo, dry)
        if args.push:
            run(["git", "push"], repo, dry)
    else:
        print("Not committed. Review the changes above, then commit with --commit (or by hand).")


if __name__ == "__main__":
    main()
